============================================================================
Autor: Bartosz Laufer,                                   Krakow, 30.03.2025
============================================================================

 Zawartosc:
============

Katalog zadania zawiera 3 programy w jezyku C które są czescia zadania 3

------------------------------------------------------------------------

* Jak uruchomic program:
========================

Katalog zawiera program Makefile do kompilacji, linkowania
i uruchamiania powyzszych programow

-> Aby uruchomic program, nalezy w line polecen powloki wykonac:
       make
->Aby urchomic program, należy w line polecen powloki wykonać komendę:
make run-"podpunkt zadania"

-> Aby wyczyscic zawartosc katalogu nalezy wykonac:
       make clean




===========================================================================



