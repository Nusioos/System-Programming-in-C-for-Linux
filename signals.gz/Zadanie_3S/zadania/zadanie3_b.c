#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
int main(int argc, char *argv[])  {
    pid_t pid = fork();

    if (pid == 0) {  
        execlp(argv[1], argv[1], NULL);
        perror("nie dziala");
        exit(1);
    } else {  
        sleep(2); 
        
 
        if (kill(pid, 0) == 0) {
            printf(" SIGUSR1 do procesu %d\n", pid);
            kill(pid, SIGUSR1);
            sleep(1);
        }
      

        if (kill(pid, 0) == 0) {
            printf(" SIGTERM do procesu %d\n", pid);
            kill(pid, SIGTERM);
            sleep(1);
        }

        if (kill(pid, 0) == 0) {
            printf(" SIGINT do procesu %d\n", pid);
            kill(pid, SIGINT);
        }
        else {
            if (errno == ESRCH) {
                printf("proces %d nie istnieje\n", pid);
            }
        }
        
        int status;
        waitpid(pid, &status, 0);

        if (WIFEXITED(status)) { // sprwadzamy czy proces umira normalnie
            printf("Proces %d skoncyzl sie normlanie status: %d\n", pid, WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
            int sig = WTERMSIG(status);
            printf("Proces %d został zakonczony poprzez sygnal %d (%s)\n", pid, sig, strsignal(sig));
        }
    }
    return 0;
}