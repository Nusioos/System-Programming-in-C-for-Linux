#define _POSIX_C_SOURCE 200112L
#define _XOPEN_SOURCE 500
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void signal_default(int sig) {
    printf("\nsygnal otrzymany: %d (default przechwyt)\n", sig);
 
    exit(0);
}


void signal_ignore(int sig) {
    printf("\nsygnal otrzymany: %d (doszlo od ignoracji PLIKU)\n", sig);
}


void signal_handle(int sig) {
    printf("\nsygnal otrzymany: %d (przechwyceno PLIK z handlerem)\n", sig);
}

int main() {
    printf("PID: %d\n", getpid());
    signal(SIGINT, signal_default);


    signal(SIGTERM, signal_ignore);

  
    signal(SIGUSR1, signal_handle);

    printf("Program czeka na sygnal\n");


    while(1) {
        pause();  
    }

    return 0;
}
