#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

void sig_handler(int sig) {
    printf("Lider grupy otrzymał sygnał %d, ale go ignoruje.\n", sig);
}

int main(int argc, char *argv[]) {
    pid_t child_pid = fork();

    if (child_pid < 0) {
        printf("widelec");
        exit(1);
    }

    if (child_pid == 0) { 
        setpgid(0, 0); 
        signal(SIGTERM, sig_handler); //  handler sygnalu ktory ma tylko lider

        for (int i = 0; i < 3; i++) { 
            pid_t pid = fork();
            if (pid == 0) { 
                execlp(argv[1], argv[1], NULL);
                perror("excelp stwierdzil ze nie bedzie wspolpracowac");
                exit(1);
            }
        }

        int status;
        pid_t wpid;
        while ((wpid = wait(&status)) > 0) {
            if (WIFEXITED(status)) {
                printf("Proces %d konczy się ze statusem %d.\n", wpid, WEXITSTATUS(status));
            } else if (WIFSIGNALED(status)) {
                printf("Proces %d konczy się sygnalem %d (%s).\n", wpid, WTERMSIG(status), strsignal(WTERMSIG(status)));
            }
        }
        exit(0);
    } else { 
        sleep(2); 

        pid_t pgid = getpgid(child_pid);
        if (pgid > 0) {
            printf("sygnał wysłany do grupy procesów %d\n", pgid);
            kill(-pgid, SIGTERM);
        } else {
            perror("getpgid umarl");
        }

        int status;
        waitpid(child_pid, &status, 0);
        if (WIFEXITED(status)) {
            printf("Lider grupy zakończył się ze statusem %d.\n", WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
            printf("Lider grupy został zakończony sygnałem %d (%s).\n", WTERMSIG(status), strsignal(WTERMSIG(status)));
        }
    }
    return 0;
}