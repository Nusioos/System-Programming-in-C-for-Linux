#ifndef SEGMENT_H
#define SEGMENT_H

#define NELE 20
#define NBUF 5

#define SHM_NAME "/shm_bufor"
#define SEM_FULL "/sem_full"
#define SEM_EMPTY "/sem_empty"
#define SEM_MUTEX "/sem_mutex"

typedef struct {
    char element[NELE];
} Towar;

typedef struct {
    Towar bufor[NBUF];
    int wstaw;
    int wyjmij;
} SegmentPD;

#endif