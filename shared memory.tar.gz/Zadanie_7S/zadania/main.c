#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/wait.h>
#include "segment.h"

void cleanup() {
    shm_unlink(SHM_NAME);
    sem_unlink(SEM_FULL);
    sem_unlink(SEM_EMPTY);
    sem_unlink(SEM_MUTEX);
}

void sig_handler(int sig) {
    exit(0);
}

int main() {
    signal(SIGINT, sig_handler);
    atexit(cleanup);

    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    ftruncate(shm_fd, sizeof(SegmentPD));
    SegmentPD *ptr = mmap(NULL, sizeof(SegmentPD), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    ptr->wstaw = 0;
    ptr->wyjmij = 0;

    sem_open(SEM_FULL, O_CREAT, 0666, 0);
    sem_open(SEM_EMPTY, O_CREAT, 0666, NBUF);
    sem_open(SEM_MUTEX, O_CREAT, 0666, 1);

    pid_t pid1 = fork();
    if (pid1 == 0) {
        execlp("./bin/producent", "producent", NULL);
        perror("execlp producent");
        exit(1);
    }
    pid_t pid2 = fork();
    if (pid2 == 0) {
        execlp("./bin/konsument", "konsument", NULL);
        perror("execlp konsument");
        exit(1);
    }
    
    wait(NULL);
    wait(NULL);
    return 0;
}