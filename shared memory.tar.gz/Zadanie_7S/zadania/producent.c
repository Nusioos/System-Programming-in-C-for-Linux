#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <string.h>
#include "segment.h"

int main() {
    int shm_fd = shm_open(SHM_NAME, O_RDWR, 0666);
    SegmentPD *shm = mmap(NULL, sizeof(SegmentPD), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);

    sem_t *sem_full = sem_open(SEM_FULL, 0);
    sem_t *sem_empty = sem_open(SEM_EMPTY, 0);
    sem_t *sem_mutex = sem_open(SEM_MUTEX, 0);

    int fd_in = open("input.txt", O_RDONLY);
    char buf[NELE];
    ssize_t bytes;

    while ((bytes = read(fd_in, buf, NELE)) > 0) {
        sem_wait(sem_empty);
        sem_wait(sem_mutex);

        memcpy(shm->bufor[shm->wstaw].element, buf, bytes);
        shm->wstaw = (shm->wstaw + 1) % NBUF;
        printf("[PRODUCENT] Wysłano porcję: %s\n", buf);
        fflush(stdout);
        sem_post(sem_mutex);
        sem_post(sem_full);

        write(STDOUT_FILENO, "Producent: ", 11);
        write(STDOUT_FILENO, buf, bytes);
        write(STDOUT_FILENO, "\n", 1);

        sleep(rand() % 2 + 1);
    }
    sem_wait(sem_empty);
    sem_wait(sem_mutex);
    strncpy(shm->bufor[shm->wstaw].element, "__EOF__", NELE);
    shm->wstaw = (shm->wstaw + 1) % NBUF;
    sem_post(sem_mutex);
    sem_post(sem_full);
    close(fd_in);
    return 0;
}