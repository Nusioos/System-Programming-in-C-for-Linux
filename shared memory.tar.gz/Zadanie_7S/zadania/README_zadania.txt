============================================================================
Autor: Bartosz Laufer,                                   Krakow, 07.05.2025
============================================================================

 Zawartość:
============

Katalog zadania zawiera 4 programy w języku C które są częścią  zadania nr.7 oraz Makefile

------------------------------------------------------------------------

* Jak uruchomić program:
========================

Katalog zawiera program Makefile do kompilacji, linkowania i uruchamiania powyższych programów

- Aby skompilować programy, należy w linii poleceń powłoki wykonać:
  make

- Aby uruchomić program, należy w linii poleceń powłoki wykonać komendę:
  make run

-Aby wyczyścić zawartość katalogu należy wykonać:
  make clean

-Aby porównać pliki wejściowe i wyjściowe:
  make check




===========================================================================



