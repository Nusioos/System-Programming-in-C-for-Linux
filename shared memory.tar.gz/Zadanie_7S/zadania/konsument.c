#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <string.h>
#include "segment.h"

int main() {
    int shm_fd = shm_open(SHM_NAME, O_RDWR, 0666);
    SegmentPD *shm = mmap(NULL, sizeof(SegmentPD), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);

    sem_t *sem_full = sem_open(SEM_FULL, 0);
    sem_t *sem_empty = sem_open(SEM_EMPTY, 0);
    sem_t *sem_mutex = sem_open(SEM_MUTEX, 0);

    int fd_out = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (fd_out == -1) {
        perror("open output.txt");
        exit(EXIT_FAILURE);
    }
    char buf[NELE];

    while (1) {
        sem_wait(sem_full);
        sem_wait(sem_mutex);

        memcpy(buf, shm->bufor[shm->wyjmij].element, NELE);
        
        shm->wyjmij = (shm->wyjmij + 1) % NBUF;
        if (strncmp(buf, "__EOF__", 7) == 0) {
            printf("[KONSUMENT] Otrzymano sygnał zakończenia.\n");
            break;
        }
        printf("[KONSUMENT] Odebrano porcję: %s\n", buf);
        fflush(stdout);
        sem_post(sem_mutex);
        sem_post(sem_empty);

        write(fd_out, buf, strnlen(buf, NELE));

        write(STDOUT_FILENO, "Konsument: ", 11);
        write(STDOUT_FILENO, buf, NELE);
        write(STDOUT_FILENO, "\n", 1);

        sleep(rand() % 2 + 1);
    }

    close(fd_out);
    return 0;
}