============================================================================
Autor: Bartosz Laufer,                                   Krakow, 09.03.2025
============================================================================

 Zawartosc:
============

Katalog Zadanie_7S zawiera jeden podkatalog zadania w którym znajduje się plik Makefile oraz 4 programy do wykonania zadania
------------------------------------------------------------------------

* Jak uruchomic program:
========================

Katalog Zadanie_7S zawiera podkatalog zadania gdzie w pliku README_zadania.txt znajdują się dalsze instrukcje

===========================================================================



