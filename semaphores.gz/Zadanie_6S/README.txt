============================================================================
Autor: Bartosz Laufer,                                   Krakow, 09.03.2025
============================================================================

 Zawartosc:
============

Katalog Zadanie_1S zawiera jeden podkatalog zadania w którym znajduje się plik Makefile
kolejny plik README_zadania , plik drzewo_genealogiczne.txt i plik drzewo_gen.txt z czego drzewo_genealogiczne.txt sluzy do zapisywania odpowiedzi z zadania D a drzewo_gen.txt to drzewko narysowane przeze mnie
------------------------------------------------------------------------

* Jak uruchomic program:
========================

Katalog Zadanie_1S zawiera podkatalog zadania gdzie w pliku README_zadania.txt znajaduje się dalsze instrukcje

===========================================================================



