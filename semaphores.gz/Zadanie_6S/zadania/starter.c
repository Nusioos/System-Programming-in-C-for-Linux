#include "sem_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <fcntl.h>

#define SEM_NAME "/my_sem"
#define FILE_NAME "numer.txt"

void cleanup() {
    unlink_named_semaphore(SEM_NAME);
    printf("Semafor zniszczony.\n");
}

void sigint_handler(int sig) {
    printf("SIGINT odebrany usuwam semafor.\n");
    exit(EXIT_SUCCESS);
}

int main(int argc, char* argv[]) {
    if (argc < 4) {
        fprintf(stderr, "Usage: %s <num_processes> <num_sections> <use_critical>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int num_processes = atoi(argv[1]);
    int num_sections = atoi(argv[2]);
    int use_critical = atoi(argv[3]);

    signal(SIGINT, sigint_handler);
    atexit(cleanup);

    //numer.txt
    FILE* file = fopen(FILE_NAME, "w");
    fprintf(file, "0\n");
    fclose(file);

    if (use_critical) {
        sem_t* sem = create_named_semaphore(SEM_NAME, 1);
        CheckError(sem != NULL);
        CheckError(close_named_semaphore(sem));
    }

    for (int i = 0; i < num_processes; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            char sections_str[10], crit_str[2];
            sprintf(sections_str, "%d", num_sections);
            sprintf(crit_str, "%d", use_critical);
            execlp("./process", "process", sections_str, crit_str, NULL);
            perror("execlp");
            exit(EXIT_FAILURE);
        }
    }

    for (int i = 0; i < num_processes; i++) wait(NULL);

 
    file = fopen(FILE_NAME, "r");
    int result;
    fscanf(file, "%d", &result);
    fclose(file);

    int expected = num_processes * num_sections;
    printf("Końcowy numer: %d (oczekiwano %d)\n", result, expected);
    return 0;
}
