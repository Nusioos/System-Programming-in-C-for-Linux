============================================================================
Autor: Bartosz Laufer,                                   Krakow, 23.04.2025
============================================================================

 Zawartość:
============

Katalog zadania zawiera 4 programy w języku C które są częścią  zadania nr.6 oraz make faile

------------------------------------------------------------------------

* Jak uruchomić program:
========================

Katalog zawiera program Makefile do kompilacji, linkowania
i uruchamiania powyższych programów

-> Aby uruchomić program, należy w linię poleceń powłoki wykonać:
       make
->Aby uruchomić program, należy w linię poleceń powłoki wykonać komendę:
make run


-> Aby wyczyścić zawartość katalogu należy wykonać:
       make clean




===========================================================================



