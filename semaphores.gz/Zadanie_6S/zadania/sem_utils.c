#include "sem_utils.h"
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

sem_t* create_named_semaphore(const char* name, unsigned int value) {
    sem_t* sem = sem_open(name, O_CREAT | O_EXCL, 0666, value);
    return (sem == SEM_FAILED) ? NULL : sem;
}

sem_t* open_named_semaphore(const char* name) {
    sem_t* sem = sem_open(name, 0);
    return (sem == SEM_FAILED) ? NULL : sem;
}

int close_named_semaphore(sem_t* sem) {
    return (sem_close(sem) == -1) ? 0 : 1;
}

int unlink_named_semaphore(const char* name) {
    return (sem_unlink(name) == -1) ? 0 : 1;
}

int sem_wait_checked(sem_t* sem) {
    return (sem_wait(sem) == -1) ? 0 : 1;
}

int sem_post_checked(sem_t* sem) {
    return (sem_post(sem) == -1) ? 0 : 1;
}

int sem_get_value_checked(sem_t* sem, int* val) {
    return (sem_getvalue(sem, val) == -1) ? 0 : 1;
}
