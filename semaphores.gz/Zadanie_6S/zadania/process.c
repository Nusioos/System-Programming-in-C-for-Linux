#include "sem_utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>

#define SEM_NAME "/my_sem"
#define FILE_NAME "numer.txt"

void critical_section() {
    FILE* file = fopen(FILE_NAME, "r+");
    if (!file) {
        perror("fopen");
        exit(EXIT_FAILURE);
    }

    int num;
    fscanf(file, "%d", &num);
    printf("PID %d: read %d\n", getpid(), num);
    fseek(file, 0, SEEK_SET);

    sleep(rand() % 2);  // symulacja pracy

    num++;
    fprintf(file, "%d\n", num);
    fflush(file);
    fclose(file);

    printf("PID %d: wrote %d\n", getpid(), num);
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <num_sections> <use_critical>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int sections = atoi(argv[1]);
    int use_critical = atoi(argv[2]);

    srand(time(NULL) ^ getpid());

    sem_t* sem = NULL;
    if (use_critical) {
        sem = open_named_semaphore(SEM_NAME);
        CheckError(sem != NULL);
    }

    for (int i = 0; i < sections; i++) {
        if (use_critical) CheckError(sem_wait_checked(sem));
        printf("PID %d wchodzenie do critical section\n", getpid());
        critical_section();
        printf("PID %d wychodzenie z critical section\n", getpid());
        if (use_critical) CheckError(sem_post_checked(sem));
        sleep(1);
    }

    if (use_critical) CheckError(close_named_semaphore(sem));
    return 0;
}
