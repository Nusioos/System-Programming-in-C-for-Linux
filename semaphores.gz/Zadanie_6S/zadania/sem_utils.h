#ifndef SEM_UTILS_H
#define SEM_UTILS_H

#include <semaphore.h>

sem_t* create_named_semaphore(const char* name, unsigned int value);
sem_t* open_named_semaphore(const char* name);
int close_named_semaphore(sem_t* sem);
int unlink_named_semaphore(const char* name);
int sem_wait_checked(sem_t* sem);
int sem_post_checked(sem_t* sem);
int sem_get_value_checked(sem_t* sem, int* val);

#define CheckError(val) if (!(val)) { perror("nie dziala sem.h"); exit(EXIT_FAILURE); }

#endif
