============================================================================
Autor: Bartosz Laufer,                                   Krakow, 30.03.2025
============================================================================

 Zawartość:
============

Katalog zadania zawiera program w języku C który jest zadaniem nr.4 oraz plik input z wejściem potoku i plik output.txt z wyjściem potoku.

------------------------------------------------------------------------

* Jak uruchomić program:
========================

Katalog zawiera program Makefile do kompilacji, linkowania
i uruchamiania powyższych programów

-> Aby uruchomić program, należy w linię poleceń powłoki wykonać:
       make
->Aby uruchomić program, należy w linię poleceń powłoki wykonać komendę:
make run

->Aby porównać pliki należy wpisać komendę make diff

-> Aby wyczyścić zawartość katalogu należy wykonać:
       make clean




===========================================================================



