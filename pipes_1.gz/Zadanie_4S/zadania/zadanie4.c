#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>

#define BUF_SIZE 64

int main() {
    int fd[2];
    pid_t pid;
    char buffer[BUF_SIZE];
    srand(time(NULL));

    if (pipe(fd) == -1) {
        perror("pipe dead");
        exit(EXIT_FAILURE);
    }

    pid = fork();

    if (pid < 0) {
        perror("widelec dead");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        
        close(fd[1]); 
        int out_fd = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (out_fd < 0) {
            perror("output umarł");
            exit(EXIT_FAILURE);
        }

        ssize_t bytes_read;
        while ((bytes_read = read(fd[0], buffer, BUF_SIZE)) > 0) {
            write(out_fd, buffer, bytes_read);
            write(STDOUT_FILENO, "Konsument otrzymał:\n", 40);
            write(STDOUT_FILENO, buffer, bytes_read);
            write(STDOUT_FILENO, "\n", 1);
            sleep(rand() % 5);
        }

        close(out_fd);
        close(fd[0]);
        exit(0);
    } else {
      
        close(fd[0]);
        int in_fd = open("input.txt", O_RDONLY);
        if (in_fd < 0) {
            perror("output umarł");
            exit(EXIT_FAILURE);
        }

        ssize_t bytes_read;
        while ((bytes_read = read(in_fd, buffer, BUF_SIZE)) > 0) {
            write(fd[1], buffer, bytes_read);
            write(STDOUT_FILENO, "Producent wysłał: \n", 18);
            write(STDOUT_FILENO, buffer, bytes_read);
            write(STDOUT_FILENO, "\n", 1);
            sleep(rand() % 5);
        }

        close(in_fd);
        close(fd[1]);
        wait(NULL); 
    }

    return 0;
}
