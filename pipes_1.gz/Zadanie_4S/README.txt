============================================================================
Autor: Bartosz Laufer,                                   Kraków, 30.03.2025
============================================================================

 Zawartość:
============

Katalog Zadanie_4S zawiera jeden podkatalog zadania w którym znajduje się plik Makefile
kolejny plik README_zadania 
------------------------------------------------------------------------

* Jak uruchomić program:
========================

Katalog Zadanie_4S zawiera podkatalog zadania gdzie w pliku README_zadania.txt znajdują się dalsze instrukcje

===========================================================================



