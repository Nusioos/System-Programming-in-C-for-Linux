#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>

#define FIFO_NAME "myfifo"
#define BUF_SIZE 64

int main() {
    char buffer[BUF_SIZE];
    srand(time(NULL));

    int out_fd = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (out_fd < 0) {
        perror("Nie można otworzyć output.txt");
        exit(EXIT_FAILURE);
    }

    int fifo_fd = open(FIFO_NAME, O_RDONLY);
    if (fifo_fd < 0) {
        perror("Nie można otworzyć FIFO (read)");
        exit(EXIT_FAILURE);
    }

    ssize_t bytes_read;
    while ((bytes_read = read(fifo_fd, buffer, BUF_SIZE)) > 0) {
        write(out_fd, buffer, bytes_read);
        write(STDOUT_FILENO, "Konsument otrzymał:\n", 21);
        write(STDOUT_FILENO, buffer, bytes_read);
        write(STDOUT_FILENO, "\n", 1);
        sleep(rand() % 3);
    }

    close(fifo_fd);
    close(out_fd);
    return 0;
}
