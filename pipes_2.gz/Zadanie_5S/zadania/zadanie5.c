#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/stat.h>

#define BUF_SIZE 64
#define FIFO_NAME "fifo_producent_konsument"

void remove_fifo() {
    unlink(FIFO_NAME);
}

int main() {
    pid_t pid;
    char buffer[BUF_SIZE];
    srand(time(NULL));


    if (mkfifo(FIFO_NAME, 0666) == -1) {
        perror("mkfifo");
    
    }

   
    atexit(remove_fifo);

    pid = fork();

    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
    
        int out_fd = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (out_fd < 0) {
            perror("Nie można otworzyć output.txt");
            exit(EXIT_FAILURE);
        }

        int fifo_fd = open(FIFO_NAME, O_RDONLY);
        if (fifo_fd < 0) {
            perror("Nie można otworzyć FIFO (read)");
            exit(EXIT_FAILURE);
        }

        ssize_t bytes_read;
        while ((bytes_read = read(fifo_fd, buffer, BUF_SIZE)) > 0) {
            write(out_fd, buffer, bytes_read);
            write(STDOUT_FILENO, "Konsument otrzymał:\n", 21);
            write(STDOUT_FILENO, buffer, bytes_read);
            write(STDOUT_FILENO, "\n", 1);
            sleep(rand() % 5);
        }

        close(fifo_fd);
        close(out_fd);
        exit(0);
    } else {
   
        int in_fd = open("input.txt", O_RDONLY);
        if (in_fd < 0) {
            perror("Nie można otworzyć input.txt");
            exit(EXIT_FAILURE);
        }

        int fifo_fd = open(FIFO_NAME, O_WRONLY);
        if (fifo_fd < 0) {
            perror("Nie można otworzyć FIFO (write)");
            exit(EXIT_FAILURE);
        }

        ssize_t bytes_read;
        while ((bytes_read = read(in_fd, buffer, BUF_SIZE)) > 0) {
            write(fifo_fd, buffer, bytes_read);
            write(STDOUT_FILENO, "Producent wysłał:\n", 19);
            write(STDOUT_FILENO, buffer, bytes_read);
            write(STDOUT_FILENO, "\n", 1);
            sleep(rand() % 5);
        }

        close(fifo_fd);
        close(in_fd);
        wait(NULL);  // czekaj na dziecko
    }

    return 0;
}
