============================================================================
Autor: Bartosz Laufer,                                   Krakow, 15.04.2025
============================================================================

 Zawartość:
============

Katalog zadania zawiera programy w języku C który jest zadaniem nr.5 oraz plik input z wejściem potoku.

------------------------------------------------------------------------

* Jak uruchomić program:
========================

Katalog zawiera program Makefile do kompilacji, linkowania
i uruchamiania powyższych programów

-> Aby uruchomić program, należy w linię poleceń powłoki wykonać:
       make
->Aby uruchomić programy, należy w linię poleceń powłoki wykonać komendę:
make "tutaj podpunkt zadania"

->Aby porównać pliki należy wpisać komendę make diff

-> Aby wyczyścić zawartość katalogu należy wykonać:
       make clean




===========================================================================



